<?php
$DB_SERVER = "localhost";
//$DB_SERVER = "10.0.40.113";
$DB_NAME = "project";
$DB_USER = "root";
$DB_PASS = "zyl741641";


//$dirData = "D:\Users";
//$dirLog = "D:\hancs\programing\bendev\data\log";
//$fileLog = "D:\hancs\programing\bendev\data\log\log.txt";
?>