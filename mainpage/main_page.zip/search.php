<html>
<head>
<!--
// This script adds data to a database table.
// Created on: 20170315
// Created by: Ben Han
// Modified on: 20170329
// Modified by: Ben Han
-->
	<title>SearchResult</title>
	<a href="http://159.226.67.97/student2017/201618012115047/main_page/index.html">Back To Mainpage</a>
</head>
<body>

<?php
//error_reporting(0);
header("Content-Type:text/html; charset=utf-8");
session_start();
set_time_limit(0);
require "confzyl.php";
$user_id = "zyl";//$_SESSION['username'];
print "<fieldset><legend>Hello, " . $user_id . "!"  . "</legend><br>";
$transform=array("9606"=>"human","10090"=>"mouse");
echo "<b>Search For ID:</b>".$_POST['ProteinID']."<br>";
echo "<b>Search For Taxon:</b>".$_POST['taxon']."<br>";
if(isset($_POST)){
	$ProteinID = trim($_POST['ProteinID']);
	$taxon = $_POST['taxon'];
	
	if(($ProteinID == '')||($taxon == '')){
		print "<font color = red>You have not input all required data!</font><BR><BR>";
	}else{
		if(strcmp($taxon,"human"))
		{
			$taxon_q='10090';
		}
		else if(strcmp($taxon,"mouse"))
		{
			$taxon_q='9606';
		}
		$mysqli = new mysqli($DB_SERVER, $DB_USER, $DB_PASS, $DB_NAME);
		//�ж������Ƿ�ɹ�
		if ($mysqli->connect_error) 
		{
			die("Connection Fail: " . $conn->connect_error."<br>");
		}
		echo "Connection Successed"."<br>";
		//echo $taxon_id."<br>";
		$index = 0;
		$myquery = "SELECT protein.ID,protein.symbol,protein.name,protein.taxon,sequence.seq  FROM protein INNER JOIN sequence ON protein.ID =sequence.id WHERE PROTEIN.ID='$ProteinID' and taxon = '$taxon_q'";
		$result=$mysqli->query($myquery);
		//�жϷ��ؽ���Ƿ�Ϊ��
		if($result->num_rows ==0){
			echo "<font color = red>Sorry,There is no such records in our database</font>";
		}
		else{
		print "<strong style=font-size:40px;color:red>Search Result</strong>";
		print "<table border=thin><BR>";
		print "<tr><td>Gene_Symbol</td><td>Protein_id</td><td>Protein_Name</td><td>Taxon</td><td>Protein_sequence</td></tr><BR>";
		while($row=$result->fetch_assoc()){
			$prot_id = $row['ID'];
			$symbol = $row['symbol'];
			$name = $row['name'];
			$sequence = $row['seq'];
			$sequence = substr($sequence,0,20)."........";
			$taxon_id = $row['taxon'];
			print "<tr>";
			print"<td>$symbol</td><td>". "<a href='http://www.ebi.ac.uk/QuickGO/GSearch?q=" . $prot_id ."#1=2'>". $prot_id . "</a></td><td>$name</td><td>$taxon</td><td>$sequence</td>";
			print "</tr>";	
		}
		print "</table>";
		}
	}
}
?>
</fieldset>
</body>
</html>